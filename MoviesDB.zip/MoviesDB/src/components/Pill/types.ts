export interface iPill {
    title: string;
    color: string;
}