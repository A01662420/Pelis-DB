export { getPopular } from './movies/getPopularMovies';
export { getNowPlaying } from './movies/getNowPlaying';
export { getTopRated } from './movies/getTopRated';
export { getDetails } from './movies/getDetails';
export { getRecommendations } from './movies/getRecommendations';