export { Home } from './Home';
export { Popular } from './Popular';
export { MyFavorites } from './MyFavorites';
export { NowPlaying } from './NowPlaying';
export { TopRated } from './TopRated';
export { Show } from './Show';