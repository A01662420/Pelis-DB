export const ROUTES = {
    HOME: '/',
    POPULAR: '/popular',
    MY_FAVORITES: '/my-favorites',
    NOW_PLAYING: '/now-playing',
    TOP_RATED: '/top-rated',
    SHOW: '/show/',
}